<!-- https://baianat.github.io/vee-validate/guide/rules.html#min-value -->
<template>
    <div>
        <p>Your name is {{ submitaName }}</p>
        <form @submit="checkForm" id="form_test">
            <!--<p>-->
                <!--<label for="name">Name</label>-->
                <!--<input id="name" v-model="name" type="text" name="name">-->
                <!--<span v-if="error">{{ error }}</span>-->
            <!--</p>-->
            <p>
                <label for="name">Name</label>
                <input id="name" v-validate="'required|alpha|min:2'" v-model="name" type="text" name="name">
                <span>{{ errors.first('name') }}</span>
            </p>


            <p>
                <label for="email">Email</label>
                <input id="email" v-validate="'required|email'" name="email" type="text">
                <span>{{ errors.first('email') }}</span> <!-- name="email" -->
            </p>

            <p>
                <label for="number">Numbar</label>
                <input id="number" v-validate="'required|numeric'" name="number" type="text">
                <span>{{ errors.first('number') }}</span> <!-- name="number" -->
            </p>
            <p>
                <span class="select">
                  <select v-validate="'included:1,2,3'" name="in_field" data-vv-as="selected">
                  <!--<select v-validate="'excluded:1,2,3'" name="not_in_field" data-vv-as="selected">-->
                    <option value="1">One</option>
                    <option value="2">Two</option>
                    <option value="3">Three</option>
                    <option value="4">Invalid</option>
                  </select>
                </span>
            </p>
            <p>
                <label for="url">Url</label>
                <input id="url" v-validate="'required|url'" name="url" type="text">
                <span>{{ errors.first('url') }}</span> <!-- name="number" -->
            </p>
            <p>
                <input type="submit" value="Submit">
            </p>
            <button @click="resets">Reset</button>
        </form>
    </div>
</template>

<script>
    // if need include only in this page some vue
    require('../bootstrap');
    import VeeValidate  from 'vee-validate';
    window.Vue.use(VeeValidate);


    export default {
        data: function() {
            return {
                name: '',
                error: '',
                submitaName: '',
            }
        },
        methods: {
            resets: function(){
              var form_reset = document.getElementById('form_test');
                  form_reset.reset();
            },
            checkForm: function (e){
                e.preventDefault();

                if(this.name == ''){
                    this.error = 'Write your name';
                }else{
                    this.submitaName = this.name;
                }

            }
        }
    }
</script>

<style scoped>

</style>