<template>
    <div>
        <p>{{ msg }}</p>
        <input v-model="showMess">{{ showMess }}
    </div>
</template>

<script>
    export default {
       data: function () {
           return {
               msg: '',
               showMess: '',
           }
       },
        watch:{
            showMess(value){
                console.log(value);
                 this.msg = value;
            }
        }
    }
</script>

<style scoped>

</style>