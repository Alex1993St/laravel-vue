<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('test', function () {
    event(new App\Events\StatusLiked('Guest'));
    return "Event has been sent!";
});

Route::get('/', function () {
    return view('welcome');
});

Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');


Route::get('/pusher', 'PusherController@index')->name('pusher');
Route::get('/bags', 'PusherController@bags')->name('bags');
Route::get('/ptb', 'PusherController@pusherToBags')->name('ptb');

Route::get('/vue', 'PusherController@vue')->name('vue');

Route::get('/goods', 'PusherController@goods')->name('goods');
Route::get('/brands', 'PusherController@brands')->name('brands');

Route::group(['middleware' => 'auth'], function (){
    Route::get('/getBrandsGoods', 'PusherController@getBrandsGoods')->name('getBrandsGoods');
});
Route::get('/getGoodsBrand', 'PusherController@getGoodsBrand')->name('getGoodsBrand');


//http://127.0.0.1:8000/v1/companies/index but it only to vue if remove prefix need delete in vue it too
//This render page '/vue
Route::group(['prefix' => 'api/v1', 'namespace' => 'Api\V1', 'as' => 'api.'], function () {
    Route::resource('companies', 'CompaniesController', ['except' => ['create', 'edit']]);
});