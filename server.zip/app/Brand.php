<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Faker\Factory;

class Brand extends Model
{
    protected $table = 'brands';
    public $fillable = ['brand'];
    public $timestamps = false;
    protected $hidden = ['pivot'];

    public static function saveBrand()
    {
        $faker = Factory::create();

        for($i = 0; $i < 6; $i++){
            $save[] = [
                'brand' => $faker->company
            ];
        }

        self::insert($save);
    }

    public static function bm()
    {
        return Brand::with('brand_many')->get()->toArray();
    }


    public function brand_many()
    {
        return $this->belongsToMany('\App\Goods', 'brand-goods', 'brands_id', 'goods_id');
    }
}
