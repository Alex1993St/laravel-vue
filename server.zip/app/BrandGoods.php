<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class BrandGoods extends Model
{
    //if it delete it still work
    protected $table = 'brand-goods';
    public $fillable = ['goods_id', 'brands_id'];
    public $timestamps = false;
    protected $hidden = ['pivot'];
}
