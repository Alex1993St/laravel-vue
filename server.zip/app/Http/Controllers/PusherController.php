<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Pusher;
use App\Events\StatusLiked;
use App\Bag;
use App\Goods;
Use App\Brand;

class PusherController extends Controller
{
    public function index()
    {
       $data= Pusher::savePusher();
       if($data){
           event(new StatusLiked($data));
       }
       dd('Ok');
    }

    public function bags()
    {
       dd(Bag::saveBag());
    }

    public function pusherToBags()
    {
        dd(Pusher::ptb()->showArray());
    }

    public function vue()
    {
        return view('admin.companies.index');
    }

    public function goods()
    {
        Goods::saveGoods();
    }

    public function brands()
    {
        Brand::saveBrand();
    }

    public function getBrandsGoods()
    {

        $brand = Brand::findOrFail(3);

        $getProd = $brand->brand_many()->get()->toArray(); // only by id
        $getProd[] = [
            'id' => 'text',
            'brand' => $brand['brand']
        ];

        return view('admin.companies.index')->with(['getProd' => $getProd]);

    }

    public function getGoodsBrand()
    {
        $goods = Goods::findOrFail(1);
        $getProd = $goods->goods_many()->get()->toArray();

        return view('admin.companies.index')->with($getProd);
    }



}
