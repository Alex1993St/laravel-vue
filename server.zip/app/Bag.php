<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Faker\Factory as Faker;


class Bag extends Model
{
    protected $table = 'bags';
    public $fillable = ['user_id', 'products'];
    public $timestamps = false;
    protected $hidden = ['id', 'user_id'];

    public static function saveBag()
    {
        try{
            $faker = Faker::create();

            $data = [];
            for($i = 0; $i < 10; $i++){
                $data[] = [
                    'products' => $faker->country,
                    'user_id' => $faker->numberBetween(1, 15)
                ];
            }

            Bag::insert($data);
            return true;
        }catch(\Exception $e){
            return $e;
        }
    }

}
