-- --------------------------------------------------------
-- Хост:                         127.0.0.1
-- Версия сервера:               5.7.23 - MySQL Community Server (GPL)
-- Операционная система:         Win32
-- HeidiSQL Версия:              9.5.0.5196
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

-- Дамп структуры для таблица pusher.bags
CREATE TABLE IF NOT EXISTS `bags` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `products` text COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `bags_user_id_foreign` (`user_id`),
  CONSTRAINT `bags_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `pushers` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Дамп данных таблицы pusher.bags: ~10 rows (приблизительно)
DELETE FROM `bags`;
/*!40000 ALTER TABLE `bags` DISABLE KEYS */;
INSERT INTO `bags` (`id`, `user_id`, `products`) VALUES
	(1, 1, 'Guatemala'),
	(2, 1, 'Cook Islands'),
	(3, 2, 'Trinidad and Tobago'),
	(4, 6, 'Spain'),
	(5, 9, 'Macedonia'),
	(6, 2, 'Libyan Arab Jamahiriya'),
	(7, 4, 'Turkmenistan'),
	(8, 9, 'Belize'),
	(9, 14, 'Spain'),
	(10, 9, 'Grenada');
/*!40000 ALTER TABLE `bags` ENABLE KEYS */;

-- Дамп структуры для таблица pusher.brand-goods
CREATE TABLE IF NOT EXISTS `brand-goods` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `goods_id` int(10) unsigned NOT NULL,
  `brands_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `brand_goods_goods_id_foreign` (`goods_id`),
  KEY `brand_goods_brands_id_foreign` (`brands_id`),
  CONSTRAINT `brand_goods_brands_id_foreign` FOREIGN KEY (`brands_id`) REFERENCES `brands` (`id`) ON DELETE CASCADE,
  CONSTRAINT `brand_goods_goods_id_foreign` FOREIGN KEY (`goods_id`) REFERENCES `goods` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Дамп данных таблицы pusher.brand-goods: ~9 rows (приблизительно)
DELETE FROM `brand-goods`;
/*!40000 ALTER TABLE `brand-goods` DISABLE KEYS */;
INSERT INTO `brand-goods` (`id`, `goods_id`, `brands_id`) VALUES
	(1, 1, 1),
	(2, 1, 2),
	(3, 1, 4),
	(4, 3, 3),
	(5, 2, 3),
	(6, 1, 3),
	(7, 5, 4),
	(8, 5, 1),
	(9, 3, 1);
/*!40000 ALTER TABLE `brand-goods` ENABLE KEYS */;

-- Дамп структуры для таблица pusher.brands
CREATE TABLE IF NOT EXISTS `brands` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `brand` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Дамп данных таблицы pusher.brands: ~6 rows (приблизительно)
DELETE FROM `brands`;
/*!40000 ALTER TABLE `brands` DISABLE KEYS */;
INSERT INTO `brands` (`id`, `brand`) VALUES
	(1, 'Tromp-Hane'),
	(2, 'Heidenreich-Eichmann'),
	(3, 'Grimes PLC'),
	(4, 'Powlowski and Sons'),
	(5, 'Lind, Botsford and Mann'),
	(6, 'Littel, Gleichner and Reilly');
/*!40000 ALTER TABLE `brands` ENABLE KEYS */;

-- Дамп структуры для таблица pusher.companies
CREATE TABLE IF NOT EXISTS `companies` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `website` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Дамп данных таблицы pusher.companies: ~0 rows (приблизительно)
DELETE FROM `companies`;
/*!40000 ALTER TABLE `companies` DISABLE KEYS */;
INSERT INTO `companies` (`id`, `name`, `address`, `website`, `email`, `created_at`, `updated_at`) VALUES
	(3, 'name', 'address', 'website', 'email', '2019-05-03 11:50:26', '2019-05-03 11:50:26');
/*!40000 ALTER TABLE `companies` ENABLE KEYS */;

-- Дамп структуры для таблица pusher.goods
CREATE TABLE IF NOT EXISTS `goods` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `company` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Дамп данных таблицы pusher.goods: ~5 rows (приблизительно)
DELETE FROM `goods`;
/*!40000 ALTER TABLE `goods` DISABLE KEYS */;
INSERT INTO `goods` (`id`, `company`) VALUES
	(1, 'Loading Machine Operator'),
	(2, 'Skin Care Specialist'),
	(3, 'Farmer'),
	(4, 'Internist'),
	(5, 'Artist');
/*!40000 ALTER TABLE `goods` ENABLE KEYS */;

-- Дамп структуры для таблица pusher.migrations
CREATE TABLE IF NOT EXISTS `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Дамп данных таблицы pusher.migrations: ~8 rows (приблизительно)
DELETE FROM `migrations`;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
	(1, '2014_10_12_000000_create_users_table', 1),
	(2, '2014_10_12_100000_create_password_resets_table', 1),
	(3, '2019_05_03_071233_create_pushers_table', 1),
	(4, '2019_05_03_080752_create_bags_table', 2),
	(5, '2019_05_03_095140_create_companies_table', 3),
	(6, '2019_05_06_063308_create_goods_table', 4),
	(7, '2019_05_06_063438_create_brands_table', 4),
	(8, '2019_05_06_063513_create_brand-goods_table', 4);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;

-- Дамп структуры для таблица pusher.password_resets
CREATE TABLE IF NOT EXISTS `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Дамп данных таблицы pusher.password_resets: ~0 rows (приблизительно)
DELETE FROM `password_resets`;
/*!40000 ALTER TABLE `password_resets` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_resets` ENABLE KEYS */;

-- Дамп структуры для таблица pusher.pushers
CREATE TABLE IF NOT EXISTS `pushers` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `age` int(10) unsigned NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Дамп данных таблицы pusher.pushers: ~15 rows (приблизительно)
DELETE FROM `pushers`;
/*!40000 ALTER TABLE `pushers` DISABLE KEYS */;
INSERT INTO `pushers` (`id`, `name`, `age`, `description`, `created_at`, `updated_at`) VALUES
	(1, 'Tracy Kohler V', 7, 'Et nulla ipsam repellendus sequi. Et est ab nemo fuga dolor quaerat autem. Fuga aliquam vitae labore necessitatibus sunt. Quaerat sit sint consectetur. Itaque quam placeat sequi dolor sint ab.', '2019-05-03 10:43:53', '2019-05-03 10:43:54'),
	(2, 'Leonardo Leffler', 5, 'Deleniti corrupti sint sed debitis non alias. Quidem aliquam ipsam esse quo. Corporis omnis consequatur ut repellendus mollitia consequatur. In inventore recusandae incidunt est occaecati.', '2019-05-03 10:43:52', '2019-05-03 10:43:54'),
	(3, 'Dr. Landen Kirlin Sr.', 0, 'Incidunt aut quibusdam error ut voluptas. Beatae rerum sunt debitis provident est asperiores occaecati et. Mollitia ea voluptatibus rerum est.', '2019-05-03 10:43:51', '2019-05-03 10:43:55'),
	(4, 'Ashtyn VonRueden DVM', 3, 'Tenetur sit et corrupti cupiditate optio voluptas qui. Recusandae quo est optio magnam dicta. Voluptatem voluptatem explicabo aliquam natus molestias dicta quas.', '2019-05-03 10:46:16', '2019-05-03 10:46:17'),
	(5, 'Dr. Rusty Pacocha', 8, 'Eaque deserunt aut consequatur perspiciatis et aut. Tempora dolorem suscipit occaecati voluptas. Et asperiores mollitia aut eos officiis laboriosam.', '2019-05-03 10:46:19', '2019-05-03 10:46:18'),
	(6, 'Micaela Osinski', 7, 'Voluptatibus sunt corporis porro. Accusantium et dolores fugit ut voluptates perferendis repellat. Qui optio consequatur numquam a.', '2019-05-03 10:46:35', '2019-05-03 10:46:35'),
	(7, 'Ms. Margret DuBuque DDS', 1, 'Officiis vel doloremque minus et. Nulla perspiciatis deleniti sit autem doloribus aliquid in. In pariatur id et vero ut nemo aut.', '2019-05-03 10:51:50', '2019-05-03 10:51:50'),
	(8, 'Mariane Koss', 5, 'Qui dolore consectetur quia. Incidunt totam aut possimus esse provident nulla. Qui dolor quidem debitis soluta maxime. Quae beatae ex accusantium sunt quo.', '2019-05-03 10:52:04', '2019-05-03 10:52:04'),
	(9, 'Laverna Corwin', 39, 'Dicta dolorem est aut sunt voluptatibus sequi ut. Rerum nesciunt itaque sunt esse. Libero nihil numquam suscipit et unde quos iure.', '2019-05-03 10:53:01', '2019-05-03 10:53:01'),
	(10, 'Prof. Dino Purdy MD', 65, 'Culpa odio quis sed. Dolorem aspernatur aliquid vel ut sint commodi in. Explicabo culpa nam illum expedita. Soluta sit est velit natus. Nesciunt eos est pariatur sunt.', '2019-05-03 10:55:03', '2019-05-03 10:55:03'),
	(11, 'Willa VonRueden', 61, 'Quia eligendi omnis placeat est quasi. Aut veritatis sunt qui quod enim. Aspernatur eius excepturi est neque nobis perferendis.', '2019-05-03 10:58:57', '2019-05-03 10:58:57'),
	(12, 'Florencio Quigley', 63, 'Perferendis est modi sunt voluptas dolorum est et deserunt. Vel accusamus odio consequatur adipisci fugiat magni. Iusto blanditiis aut quas aut modi rerum.', '2019-05-03 10:59:35', '2019-05-03 10:59:35'),
	(13, 'Eloy Waelchi', 64, 'Dolorum et quo ipsum laboriosam neque dolorem veniam. Suscipit nihil odit aliquam sapiente sunt. Accusamus perspiciatis explicabo rerum temporibus aliquam quas unde.', '2019-05-03 10:59:48', '2019-05-03 10:59:48'),
	(14, 'Braulio Nienow', 39, 'Quaerat eveniet quia omnis inventore consequatur nulla. Nam ipsa aspernatur architecto voluptatibus est inventore iste expedita. Ullam et aliquid eos non adipisci.', '2019-05-03 11:00:16', '2019-05-03 11:00:16'),
	(15, 'Mrs. Mattie Gutmann', 27, 'Alias aperiam iste exercitationem ipsa illum consequatur exercitationem. Pariatur illo nulla veritatis aut rerum repellendus accusantium. Nam nisi asperiores dolorum qui.', '2019-05-03 11:02:06', '2019-05-03 11:02:06');
/*!40000 ALTER TABLE `pushers` ENABLE KEYS */;

-- Дамп структуры для таблица pusher.users
CREATE TABLE IF NOT EXISTS `users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Дамп данных таблицы pusher.users: ~0 rows (приблизительно)
DELETE FROM `users`;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` (`id`, `name`, `email`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
	(1, 'Alex', 'alex123fx@einrot.com', '$2y$10$RpWXxadz1q3na651jMi9XOxA3RIkTTxGJzokPnk77W0wibeIAVody', '8PUWZ3saIgYuBLiCUzgCg2H2wmSUThsTHFo9TT9JSD1ur15kkAQHhaFb9pjZ', '2019-05-03 11:22:24', '2019-05-03 11:22:24');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
