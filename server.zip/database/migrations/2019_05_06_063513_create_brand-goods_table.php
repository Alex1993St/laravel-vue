<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateBrandGoodsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('brand-goods', function (Blueprint $table){
           $table->increments('id');
           $table->integer('goods_id', FALSE, TRUE);
           $table->integer('brands_id', FALSE, TRUE);
        });

        Schema::table('brand-goods', function (Blueprint $table){
           $table->foreign('goods_id')->references('id')->on('goods')->onDelete('cascade');
           $table->foreign('brands_id')->references('id')->on('brands')->onDelete('cascade');
        });

    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        //
    }
}
