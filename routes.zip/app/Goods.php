<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Faker\Factory;

class Goods extends Model
{
    protected $table = 'goods';
    public $fillable = ['title'];
    public $timestamps = false;
    protected $hidden = ['pivot'];

    public static function saveGoods()
    {
        $faker = Factory::create();

        for($i = 0; $i < 5; $i++){
            $save[] = [
                'company' => $faker->jobTitle
            ];
        }

        self::insert($save);

    }

    public function goods_many()
    {
        return $this->belongsToMany('\App\Goods', 'brand-goods', 'goods_id', 'brands_id');
    }
}
