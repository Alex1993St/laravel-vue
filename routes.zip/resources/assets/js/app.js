
/**
 * First we will load all of this project's JavaScript dependencies which
 * includes Vue and other libraries. It is a great starting point when
 * building robust, powerful web applications using Vue and Laravel.
 */

require('./bootstrap');

window.Vue = require('vue');
import VueRouter from 'vue-router';
//import VeeValidate  from 'vee-validate';
//window.Vue.use(VeeValidate);
window.Vue.use(VueRouter);


import CompaniesIndex from './components/companies/CompaniesIndex.vue';
import CompaniesCreate from './components/companies/CompaniesCreate.vue';
import CompaniesEdit from './components/companies/CompaniesEdit.vue';
import Example from './components/companies/Example.vue';

import Test from './components/Test.vue';
import Slider from './components/Slider.vue';
import Vform from './components/Vform.vue';

const routes = [
    //Безымянный router-view автоматически получает имя default.
    {
        path: '/',
        components: {
            //default: Component_import_name,
            companiesIndex: CompaniesIndex,
            test: Test,
            slider: Slider,
            vform: Vform
        },
        //in main path /admin/companies
        // children: [{
        //     path: 'create', //use only create because all use take main path and children path
        //     component: CompaniesEdit
        //      name: 'createCompany'},
        // }, {
        //     path: 'edit/:id',
        //     components: {
        //         ....
        //     }
        // }]
        // redirect: '/b' // in need redirect redirect: { name: 'foo' }} redirect: to => {function(){}}
    },
    {
        // динамические сегменты начинаются с двоеточия
        //path: '/admin/:id', component: 'CompaniesCreate'  // in component get id => $route.params.id
        path: '/admin/companies/create',
        component: CompaniesCreate,
        name: 'createCompany'},
    {
        path: '/admin/companies/edit/:id',
        component: CompaniesEdit,
        name: 'editCompany'
    },
    {
        //http://127.0.0.1:8000/vue#/Example
        path: '/Example',
        component: Example,
        name: 'Example'

    },
    // сопоставляется со всем, начинающимся с `/user-`
    //path: '/user-*'
    // сопоставляется со всем
    //path: '*'
    //this.$route.params.pathMatch //use when use *
];

const router = new VueRouter({ routes });

const app = new Vue({
    router
}).$mount('#app');

/**
 * Next, we will create a fresh Vue application instance and attach it to
 * the page. Then, you may begin adding components to this application
 * or customize the JavaScript scaffolding to fit your unique needs.
 */

// Vue.component('example', require('./components/Example.vue'));
//
// const app = new Vue({
//     el: '#app'
// });
