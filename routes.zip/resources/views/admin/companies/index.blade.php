@extends('layouts.app')

@section('content')
    <router-link to="/">Go home</router-link>

    <div class="container">
        <div class="row">
            <div class="col-md-8 col-md-offset-2">
                <div class="panel panel-default">
                    <div class="panel-heading">Companies</div>

                    <div class="panel-body table-responsive">
                        <router-view name="companiesIndex"></router-view>
                        <router-view></router-view>
                    </div>
                </div>
            </div>
        </div>
    </div>
    @if(isset($getProd))
        @foreach($getProd as $prod)
            <p>{{ $prod['id'] }}</p>
        @endforeach
    @endif

    @if(!Auth::guest())
    <router-view name="test"></router-view>
    @endif
    <router-view name="slider"></router-view>

    <router-view name="vform"></router-view>
@endsection