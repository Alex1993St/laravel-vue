<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Pusher;
use App\Events\StatusLiked;
use App\Bag;

class PusherController extends Controller
{
    public function index()
    {
       $data= Pusher::savePusher();
       if($data){
           event(new StatusLiked($data));
       }
       dd('Ok');
    }

    public function bags()
    {
       dd(Bag::saveBag());
    }

    public function pusherToBags()
    {
        dd(Pusher::ptb()->showArray());
    }

    public function vue()
    {
        return view('admin.companies.index');
    }

}
