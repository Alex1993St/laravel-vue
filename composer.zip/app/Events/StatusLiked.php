<?php

namespace App\Events;

use Illuminate\Broadcasting\Channel;
use Illuminate\Queue\SerializesModels;
use Illuminate\Broadcasting\PrivateChannel;
use Illuminate\Broadcasting\PresenceChannel;
use Illuminate\Foundation\Events\Dispatchable;
use Illuminate\Broadcasting\InteractsWithSockets;
use Illuminate\Contracts\Broadcasting\ShouldBroadcast;

class StatusLiked implements ShouldBroadcast
{
    use Dispatchable, InteractsWithSockets, SerializesModels;

//    public $username;
//    public $message;

    public $name;
    public $age;
    public $description;

    /**
     * Create a new event instance.
     *
     * @return void
     */
//    public function __construct($username)
//    {
//        $this->username = $username;
//        $this->message  = "{$username} liked your status";
//    }
    public function __construct($data)
    {
        $this->name = $data['name'];
        $this->description  = $data['description'];
        $this->age  = $data['age'];
    }

    /**
     * Get the channels the event should broadcast on.
     *
     * @return Channel|array
     */
    public function broadcastOn()
    {
        return ['new_user'];
    }
}
