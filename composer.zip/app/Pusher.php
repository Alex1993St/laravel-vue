<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Faker\Factory as Faker;

class Pusher extends Model
{
   protected $table = "pushers";
   public $fillable = ['name', 'age', 'description'];


   public static function savePusher()
   {
      try{
          $faker = Faker::create();
          $data = [
              'name' => $faker->name,
              'age' => $faker->numberBetween(18, 70),
              'description' => $faker->text
          ];

          Pusher::insert($data);

          return $data;
      }catch (\Exception $e){
          return false;
      }
   }

    public static function ptb()
    {
        return Pusher::with('hm');
    }

    public function hm()
    {
        return $this->hasMany(\App\Bag::class, 'user_id', 'id');
    }

    public function scopeShowArray($query)
    {
        return $query->get()->toArray();
    }
}
